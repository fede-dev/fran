const Page = require('./page');
const User = require('./user');

Page.belongsTo(User, { as: 'author' }); //http://docs.sequelizejs.com/manual/associations.html

module.exports = { User, Page };